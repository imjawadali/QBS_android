// <!-- popup box javascript start here -->
function show_notification() {
    var modal = document.getElementById("notification_popup_box");

    modal.style.display = "block";
    setTimeout(function () {
        modal.style.display = "none";
    }, 1500);

}
// <!-- popup box javascript end here -->


// <!-- popup box javascript start here -->
function show_error_notification() {
    var modal = document.getElementById("error_notification_popup_box");

    modal.style.display = "block";
    setTimeout(function () {
        modal.style.display = "none";
    }, 1500);

}
// <!-- popup box javascript end here -->


// Error Notification and Notification id Start here 
const error_notification_box_text = document.getElementById('error_notification_box_text');
const notification_box_text = document.getElementById('notification_box_text');
// Error Notification and Notification id End here 


// <!-- Login Function Start here -->
async function login() {
    const username = document.getElementById('email').value;
    const Passwordinput = document.getElementById('password').value;

    if (username === '') {
        error_notification_box_text.innerText = "Please Enter Username"
        show_error_notification();
    } else if (Passwordinput === '') {
        error_notification_box_text.innerText = "Please Enter Password"
        show_error_notification();
    } else {
        var api = 'http://localhost:8000/';
        let data = {
            username: username,
            password: Passwordinput
        }
        try {
            const response = await axios.post(api, data);
            if (response.data.status === "200") {
                window.location.href = "/Dashboard"
            }
        } catch (error) {
            error_notification_box_text.innerText = error.response.data.msg;
            show_error_notification();
        }
    }

}
// <!-- Login Function End here -->


// <!-- Show Password Function Start here -->
function show_password() {

    const password = document.getElementById('password');

    if (password.type === "password") {
        password.type = "text";
    } else {
        password.type = "password";
    }

}
// <!-- Show Password Function End here -->