const Mysql = require('mysql');
const con = Mysql.createConnection({

    host: 'localhost',
    user: 'root',
    password:'',
    database:'ascend_updated_db'
});


con.connect(function(err){
    if(err){ throw err;}
    else{console.log("Connected...!"); }
});



module.exports = con;