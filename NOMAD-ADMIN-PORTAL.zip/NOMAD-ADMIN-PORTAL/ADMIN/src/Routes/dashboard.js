const express = require('express');
const router = express.Router();
const path = require('path');
const database = require("../Database/database_config");


const staticpath = path.join(__dirname, "../../DASHBOARD/public/assets/");


router.use(express.static(staticpath));

router.use(express.json());


router.get("/", async(req,res)=>{
    try{  
        req.session.user.username;  //Authenticating

        var reg_users;
        await count_registered_users().then((resp) => { reg_users=resp}).catch((err) => console.log(err));
        
         res.status(200).render('dashboard');   
     }   
    catch(error){
        res.status(401).redirect("/");
    }
});





//FUNCTION TO COUNT REGISTERED USERS
function count_registered_users() {
    var count=0;


 const promisetoken =  new Promise((resolve, rejects) => {
    database.query("select count(*) AS registered_users from users;", async function(error, results, fields) {

        if (results.length> 0) {
              resolve(count= results[0].registered_users);
        }
        else{
            rejects(error.message);
        }
    });
    
 });   

 return promisetoken;

}




module.exports = router;