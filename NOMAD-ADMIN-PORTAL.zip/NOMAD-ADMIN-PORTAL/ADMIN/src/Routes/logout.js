const express = require('express');

const router = express.Router();


router.get("/", (req, res) => {

    try {
        if (req.session.user.username) {
            req.session.destroy();
            res.status(200).json({
                "status": "200",
                "msg": "Logout Successful!"
            });
        }

    } catch (error) {
        res.status(500).json({
            "status": "500",
            "msg": "Internal Server Error! CAUSED BY: " + error.message
        });
    }

});



router.post("/", (req, res) => {

    res.status(405).json({
        "status": "405",
        "msg": "Method Not Allowed!"
    });

});


module.exports = router;