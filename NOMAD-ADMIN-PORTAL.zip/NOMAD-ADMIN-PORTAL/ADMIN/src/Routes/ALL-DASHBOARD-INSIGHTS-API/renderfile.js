const express = require("express");
const database = require('../../Database/database_config')
const router = express.Router();
router.use(express.json());


router.post('/',(req,res)=>{
    res.status(405).json({
        "status": "405",
        "msg": "Method Not Allowed!"
        
    });
});






router.get('/',(req,res)=>{
        try{
            const email = req.query.email;
          database.query("SELECT * FROM employee_engagement_survey_responses WHERE participantemail = ?",[email],(error,result)=>{
                 if(error){
                    console.log(`query error ${error}`);
                 }
                 else{
                    // if(result.length > 0){
                        console.log("query executed");
                        res.status(200).render('viewexceldata');
                        // res.status(200).json({data:result})
                    // }
                 }
          });
        }
        catch(error){
            console.log(`Catch error ${error}`);
        }
});

module.exports = router;















