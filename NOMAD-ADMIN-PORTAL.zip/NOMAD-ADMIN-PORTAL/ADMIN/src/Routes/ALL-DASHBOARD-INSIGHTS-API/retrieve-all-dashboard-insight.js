const express = require('express')
const database = require('../../Database/database_config')

const router = express.Router();





router.get("/", (req, res) => {

    try {

        var dashboard_insights=[];

        //============ QUERY TO GET COMPANY AND SURVEY NAMES FROM TOOLS TABLE
        database.query("SELECT company, surveyandassessments  FROM `tools` WHERE 1", (error, result) => {

            if (error) {

                res.status(500).json({
                    "status": "500",
                    "msg": "Internal Server Error! CAUSED BY: " + error.message
                });

            }

            else {

                if (result.length > 0) {
                    var survey_and_company_metadata = []

                    for(let i = 0; i< result.length; i++){
                        survey_and_company_metadata.push(result[i])
                    }

                    dashboard_insights.push({all_surveys_and_companies:survey_and_company_metadata});


                    //============ QUERY TO GET ALL ACTIVE PDA'S FROM TOOLS TABLE

                    
                    database.query("SELECT COUNT(*) AS count FROM tools  where surveyandassessments = ? AND status = ?",["Behavioral Benchmarking","Active"],(error,result)=>{

                        if (error) {

                            res.status(500).json({
                                "status": "500",
                                "msg": "Internal Server Error! CAUSED BY: " + error.message
                            });
            
                        }

                        else{
                            dashboard_insights.push(result[0])
                            res.status(200).send(dashboard_insights);
                        }

                    });


                }
                else{

                    res.status(404).json({
                        "status":"404",
                        "msg":"No Surveys/Assessments Found!"
                    });

                }
            }

        });

    }
    catch (error) {

        res.status(500).json({
            "status": "500",
            "msg": "Internal Server Error! CAUSED BY: " + error.message
        });

    }

});








router.post("/", (req, res) => {

    res.status(405).json({
        "status": "405",
        "msg": "Method Not Allowed!"
    });

});




module.exports = router;