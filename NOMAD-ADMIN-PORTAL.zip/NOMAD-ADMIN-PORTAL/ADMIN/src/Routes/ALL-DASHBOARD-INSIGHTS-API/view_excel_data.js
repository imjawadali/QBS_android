const express = require("express");
const database = require('../../Database/database_config')
const router = express.Router();
router.use(express.json());


router.post('/',(req,res)=>{
    res.status(405).json({
        "status": "405",
        "msg": "Method Not Allowed!"
    });
});






router.get('/',(req,res)=>{
        try{
            const email = req.query.email;
          database.query("SELECT * FROM employee_engagement_survey_responses WHERE participantemail = ?",[email],(error,result)=>{
                 if(error){
                    console.log(`query error ${error}`);
                 }
                 else{
                    if(result.length > 0){
                        var arr = [];
                        for(let i =0; i< result.length; i++){
                            arr.push([{participantemail:result[i].participantemail}]);
                            arr.push(JSON.parse(result[i].data));
                        }
                        console.log("query executed");
                        // res.status(200).render('viewexceldata');
                        console.log(result+"result");

                        res.status(200).json(arr); 
                        console.log(arr);
                        // res.status(200).json({
                        //     "msg" : result
                        // });
                    
                     }
                 }
          });
        }
        catch(error){
            console.log(`Catch error ${error}`);
        }
});

module.exports = router;















