const express = require('express');
const router = express.Router();
const path = require('path');
const database = require("../Database/database_config");

const staticpath = path.join(__dirname, "../../PDAPARTICIPANTS/public/assets/");


router.use(express.static(staticpath));
router.use(express.json)


router.get("/", (req,res)=>{
    try{  
        req.session.user.username;  //Authenticating
        res.status(200).render('pdaparticipants'); 
     }   
    catch(error){
        res.status(401).send("<h2 style=\"color:red\">Error:401 Unauthorized Access!");
    }
});
    


router.post("/", async (req, res) => {
    res.status(500).send("<h2 style=\"color:red\">Error:500 Internal Server Error!");
});




module.exports = router;