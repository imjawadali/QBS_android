const express = require('express');
const router = express.Router();
const database = require("../Database/database_config");

router.use(express.json());



router.get("/", (req,res)=>{
    try{  
        // req.session.user.username;  //Authenticating

        database.query("SELECT * from user_profile_edit_request;", async function(error, results, fields) {

            if (error) {
                console.log(error);
            }
            else{
                res.status(200).json(results);
            }
        });

  
     }   
    catch(error){
        res.status(401).send("<h2 style=\"color:red\">Error:401 Unauthorized Access!");
    }
});
    


module.exports = router;