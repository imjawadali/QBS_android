const express = require('express');
const router = express.Router();
const path = require('path');
const database = require("../Database/database_config");

router.use(express.json())


staticpath = path.join(__dirname, "../../PROJECTS/public/assets/");
router.use(express.static(staticpath));


router.get("/", (req,res)=>{
    try{  
        req.session.user.username;  //Authenticating
        res.status(200).render('projects');  
     }   
    catch(error){
        res.status(401).send("<h2 style=\"color:red\">Error:401 Unauthorized Access!");
    }
});
    


module.exports = router;