const express = require('express');
const router = express.Router();
const path = require('path');
const database = require("../Database/database_config");
var bodyParser = require('body-parser');


const staticpath = path.join(__dirname, "../../360PARTICIPANTS/public/assets/");


router.use(express.static(staticpath));

router.use(express.json());

router.get("/", (req,res)=>{
    try{  
        req.session.user.username;  //Authenticating
        res.status(200).render('360participants'); 
     }   
    catch(error){
        res.status(401).send("<h2 style=\"color:red\">Error:401 Unauthorized Access!");
    }
});
    



// router.post("/", encoder, async (req, res) => {

//     try{  
//         req.session.user.username;  //Authenticating
//         var jsondata = req.body;

//         var values = [];

//         console.log("inside API");    


//         for(var i=1; i< jsondata.length; i++){
//             values = jsondata[i].toString().split(',');

//          database.query('INSERT INTO 360surveysubjectslist (firstname, lastname, email, uniqueid, company, rank, department, designation) VALUES(?,?,?,?,?,?,?,?)', [values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7]], function(err,result) {
//             if(err) {
//                 res.status(500).write("<h4 style=\"color:red\">File Uploading Failed! "+err.message+"<h4>");
//                 res.end();
//             }
//             else{
//                     res.status(200).write("<h4 style=\"color:green\">File Uploaded Successfully!</h4>");
//                     res.end();
//             }
            
//         });  
//     }

//     }   

//     catch(error){
//         res.status(401).write("<h2 style=\"color:red\">Error:401 Unauthorized Access!");
//         res.end();
//     }
    

    
// });


module.exports = router;