const express = require('express');
const router = express.Router();
const path = require('path');
const database = require("../Database/database_config");
const session = require("express-session");
const cookieParser = require("cookie-parser");



staticpath = path.join(__dirname, "../../LOGIN/public");

router.use(express.static(staticpath));

router.use(express.json());


//Initialize Session
router.use(cookieParser());




//Setting up session
router.use(session({
    secret: "*blackops786*",
    saveUninitialized: true,
    resave: true
}));



router.get("/", (req, res) => {
    try {
        if (req.session.user.username) {
            res.status(409).redirect('/Dashboard');
        }
    } catch (error) {
        res.status(200).render('login');
    }

});



router.post("/", (req, res) => {

    try {
        var username = req.body.username;
        var password = req.body.password;


        database.query("SELECT * FROM admin WHERE id = ? and password = ? ;", [username, password], function (error, results) {
            if (error) {
                res.status(500).json({
                    "status": "500",
                    "msg": "Internal Server Error! CAUSED BY: " + error.message
                });
            }
            else {

                if (results.length > 0) {

                    //Creating a User Object 
                    const user = {
                        username: username
                    };



                    //Saving Session
                    req.session.user = user;
                    req.session.save();

                    res.status(200).json({
                        "status": "200",
                        "msg": "Login Successful!"
                    });

                }
                else {
                    res.status(401).json({
                        "status": "401",
                        "msg": "Invalid Username or Password!"
                    });
                }

            }
        });

    } catch (error) {

        res.status(500).json({
            "status": "500",
            "msg": "Internal Server Error! CAUSED BY: " + error.message
        });
    }


});



module.exports = router;