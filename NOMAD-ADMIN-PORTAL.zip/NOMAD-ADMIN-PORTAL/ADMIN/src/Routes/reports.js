const express = require('express');
const router = express.Router();
const database = require("../Database/database_config");




router.get("/", (req,res)=>{
    try{  
        // req.session.user.username;  //Authenticating
        res.status(200).render('developer_test_file');
     }   
    catch(error){
        res.status(401).redirect('/');
    }
    
});
    




module.exports = router;