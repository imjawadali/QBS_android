const express = require('express');
const router = express.Router();
const path = require('path');
const database = require("../Database/database_config");




staticpath = path.join(__dirname, "../../TOOLS/public/assets/");
router.use(express.static(staticpath));

router.use(express.json());


router.get("/", (req,res)=>{
    try{  
        req.session.user.username;  //Authenticating
        res.status(200).render('tools');  
     }   
    catch(error){
        res.status(401).send("<h2 style=\"color:red\">Error:401 Unauthorized Access!");
    }
});
    


module.exports = router;