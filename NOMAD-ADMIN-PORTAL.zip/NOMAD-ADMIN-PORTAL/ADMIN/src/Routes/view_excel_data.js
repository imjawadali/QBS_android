const express = require('express');
const path = require('path');
const router =  express.Router();
router.use(express.json());

const staticpath = path.join(__dirname, "../../360DATA/public/assets/");
router.use(express.static(staticpath));

router.get('/',(req,res)=>{
      res.render("viewexceldata");
});

module.exports = router;