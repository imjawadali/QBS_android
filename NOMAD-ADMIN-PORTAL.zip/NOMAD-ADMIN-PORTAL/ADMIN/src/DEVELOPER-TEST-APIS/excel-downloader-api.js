const express = require('express');

const router = express.Router();
router.use(express.json());
const database = require('../Database/database_config');





router.get("/",(req,res)=>{
//WRITE YOUR CODE HERE!
   var email = "shuaib@gmail.com";
//    
   database.query("SELECT * FROM employee_engagement_survey_responses WHERE participantemail = ?",[email],(error,result)=>{
             if(error){
                console.log("Query error"+error);
             }
             else{
                if(result.length>0){
                    var arr_to_be_sent =[]

                    // console.log(JSON.parse(result[2].data));
                    console.log(result);
                    
                    for(let i =0; i< result.length; i++){
                        arr_to_be_sent.push([{participantemail:result[0].participantemail}]);
                        arr_to_be_sent.push(JSON.parse(result[0].data));
                    }
                    

                    // console.log(arr_to_be_sent);
                    

                    res.status(200).json(
                        {
                            "status":"200",
                             "msg" : arr_to_be_sent
                        }
                    )
                }
             }
   });

});


router.post("/",(req,res)=>{
    res.status(405).json({
        "status":"405",
        "msg":"Method Not Allowed!"
    });
});



module.exports = router;