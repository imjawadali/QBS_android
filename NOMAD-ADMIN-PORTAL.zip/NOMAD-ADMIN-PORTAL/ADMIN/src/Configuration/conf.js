const express = require('express');
const app = express();
const port = 8000;






const signinRoute = require("../Routes/login");
const signoutRoute = require("../Routes/logout");
const dashboardRoute = require("../Routes/dashboard");
const assessmentRoute = require("../Routes/assessmentbuilder");
const surveyRoute = require("../Routes/surveybuilder");
const resumesRoute = require("../Routes/resumes");
const participants360Route = require("../Routes/360participants");
const subjectsRoute = require("../Routes/subjectssheetuploader");
const evaluatorsRoute = require("../Routes/evaluatorssheetuploader");
const insightRoute = require("../Routes/insights");
const reportsRoute = require("../Routes/reports");
const dataRoute = require("../Routes/data");
const pdalinksRoute = require("../Routes/embedpdalinks");
const inviteemailRoute = require("../Routes/invite_email");
const reminderemailRoute = require("../Routes/reminder_email");
const toolsRoute = require("../Routes/tools");
const tools360Route = require("../Routes/tools360");
const toolsassessmentRoute = require("../Routes/assessmenttools");
const toolsbenchmarkRoute = require("../Routes/benchmarktools.js");
const toolspdaRoute = require("../Routes/pdatools.js");
const pdaresponsesRoute = require("../Routes/uploadpdaresponses");
const pdaparticipantsRoute = require("../Routes/pdaparticipants");    
const benchmarkparticipantsRoute = require("../Routes/benchmarkparticipants");    
const view_active_surveys_assessmentsRoute = require("../Routes/view-active-surveys-assessments");    
const view_user_profile_edit_request = require("../Routes/view-user-profile-edit-request");    
const projectsRoute = require("../Routes/projects");



//=====================  DASHBOARD INSIGHTS RELATED VARIABLES  =====================

const survey_and_company_name_retriever_Route = require("../Routes/ALL-DASHBOARD-INSIGHTS-API/retrieve-all-dashboard-insight");


//=====================  DEVELOPER TESTING ROUTES  =====================

const test_Route = require('../DEVELOPER-TEST-APIS/excel-downloader-api');






app.set('views', '../../views');
app.set('view engine', 'ejs');



// ------------------------------------------------------------------------------------AVI,saqib WORK
const view_excel_data = require('../Routes/view_excel_data');
const renderfile = require('../Routes/ALL-DASHBOARD-INSIGHTS-API/renderfile');

app.use('/viewdata',view_excel_data);





// ------------------------------------------------------------------------------------AVI,saqib WORK

const view_data_api = require('../Routes/ALL-DASHBOARD-INSIGHTS-API/view_excel_data');

//Calling Routes 
app.use("/", signinRoute);
app.use("/Login", signinRoute);
app.use("/Logout", signoutRoute);
app.use("/Dashboard", dashboardRoute);
app.use("/Resumes", resumesRoute);
app.use("/Createsurvey", surveyRoute);
app.use("/Participants", participants360Route);
app.use("/Participants/Subjects", subjectsRoute);
app.use("/Participants/Evaluators", evaluatorsRoute);
app.use("/Data", dataRoute);
app.use("/Reports", reportsRoute);
app.use("/InviteEmail", inviteemailRoute);
app.use("/ReminderEmail", reminderemailRoute);
app.use("/Insights", insightRoute);
app.use("/Assessment", assessmentRoute);
app.use("/Tools", toolsRoute);
app.use("/360Tools", tools360Route);
app.use("/AssessmentTools", toolsassessmentRoute);
app.use("/BenchmarkTools", toolsbenchmarkRoute);
app.use("/PDATools", toolspdaRoute);
app.use("/PDAResponses", pdaresponsesRoute);
app.use("/PDAEmbed", pdalinksRoute);    
app.use("/PDAParticipants", pdaparticipantsRoute);    
app.use("/BenchmarkParticipants", benchmarkparticipantsRoute);    
app.use("/View-Active-Surveys-Assessments", view_active_surveys_assessmentsRoute);    
app.use("/View-User-Profile-Edit-Request", view_user_profile_edit_request);    
app.use("/Projects", projectsRoute);


 

//=====================  DASHBOARD INSIGHTS RELATED ROUTES  =====================

app.use("/Retrieve-All-Survey-Company-Names",survey_and_company_name_retriever_Route);



//=====================  DEVELOPER TESTING ROUTES  =====================

app.use("/Test",test_Route);
app.use("/viewexceldata",view_data_api);
app.use('/renderfile',renderfile);




app.listen(port, () => {
    console.log(`Server is listening at port# ${port}`);
});