const mysql = require('mysql');
const connection = mysql.createConnection(
    {
        host : 'localhost',
        user : 'root',
        password : '',
        database : 'zconnect'
    }
)

connection.connect(error=>{
    if(error){
      console.log("Database Connection Error"+error);
    }
    else{
        console.log("Database Connected Successfully");
    }
})
module.exports = connection;