const express = require('express');
const database = require('../../Database/database');
const router = express.Router();


router.use('/', (req, res, next) => {

    if (req.method != "GET") {
        res.status(405).json({
            "status": "405",
            "msg": "Method Not Allowed!"
        })
    }
    else {
        next();
    }

});


router.get('/', (req, res) => {
    try {
        const location = req.query.location;

        database.query("SELECT whs_name FROM zc_warehouse WHERE location = ?", [location], (error, result) => {
            if (error) {
                console.log("Query error" + error);
            }
            else {
                if (result.length > 0) {
                    res.status(200).send(result);
                }
            }
        });

    }
    catch (error) {
        res.status(500).json(
            {
                "status": "500",
                "msg": "Internal Server Error! CAUSED BY: " + error.message
            }

        )
    }
});




module.exports = router;