const express = require('express');
const database = require('../../Database/database');
const router = express.Router();


router.use('/', (req, res, next) => {

    if (req.method != "GET") {
        res.status(405).json({
            "status": "405",
            "msg": "Method Not Allowed!"
        })
    }
    else {
        next();
    }

});



router.get('/',(req,res)=>{
         database.query("SELECT whs_name,whs_code FROM zc_warehouse WHERE 1",[],(error,result)=>{
            if(error){
                console.log("Query Error"+error);
            }
            else{
                if(result.length>0){
                    res.status(200).send(result);
                }
            }
         });
});




module.exports = router;