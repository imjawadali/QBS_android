const express = require('express');
const database = require('../../Database/database');
const router = express.Router();


router.use('/', (req, res, next) => {

    if (req.method != "GET") {
        res.status(405).json({
            "status": "405",
            "msg": "Method Not Allowed!"
        })
    }
    else {
        next();
    }

});


router.get('/',(req,res)=>{
     const barcode = req.query.barcode;

     database.query("SELECT zc_stock_barcode.item_code, zc_stock_master.item_name FROM zc_stock_barcode INNER JOIN zc_stock_master WHERE zc_stock_barcode.barcode = ? AND zc_stock_master.barcode=?",[barcode,barcode],(error,result)=>{
          if(error){
            console.log("Query Error"+error);
          } 
          else{
            if(result.length>0){
                console.log(result);
                res.status(200).send(result);
            }
            else{
                res.status(401).json(
                    {
                        status : false,
                        'msg': 'Invalid Credentials'
                    }
                )
            }
          }
     });
});





module.exports = router;