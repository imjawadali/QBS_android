const express = require('express');
const connection = require('../../Database/database');
const router = express.Router();


router.use('/',(req,res,next)=>{

    if(req.method != "POST"){
        res.status(405).json({
            "status":"405",
            "msg":"Method Not Allowed!"
        })
    }
    else{
        next();
    }

});





router.post('/',(req,res)=>{
    try {
        console.log(req.body);
           const {user_code,username,password,erp_id,erp_password,email,country_code,cell_no,dlft_whs,user_group,locked,picture,super_user,receiver,allow_all_whs,version} = req.body;

           connection.query("INSERT INTO zc_users (user_code,username,password,erp_id,erp_password,email,country_code,cell_no,dlft_whs,user_group,locked,picture,super_user,receiver,allow_all_whs,version) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[user_code,username,password,erp_id,erp_password,email,country_code,cell_no,dlft_whs,user_group,locked,picture,super_user,receiver,allow_all_whs,version],(error,result)=>{
              if(error){
                 console.log("Query Error"+error);
              }
              else if(result){
                    console.log("Query Executed");
                    res.status(200).json(
                        {
                            status : true,
                            msg : 'Api Hit Successfully'
                        }
                    );
              }
           });
        
    } catch (error) {
        res.status(500).json({
            "status":"500",
            "msg":"Internal Server Error! CAUSED BY: "+error.message
        });
    }
});


module.exports = router;