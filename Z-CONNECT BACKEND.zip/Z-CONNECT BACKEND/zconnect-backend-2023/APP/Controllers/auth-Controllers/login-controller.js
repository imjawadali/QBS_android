const express = require('express');
const connection = require('../../Database/database')
const router = express.Router();




router.use('/',(req,res,next)=>{

    if(req.method != "POST"){
        res.status(405).json({
            "status":"405",
            "msg":"Method Not Allowed!"
        })
    }
    else{
        next();
    }

});





router.post('/',(req,res)=>{
    try {
        console.log(req.body);
        const {user_code,password} = req.body;
       connection.query("SELECT * FROM zc_users WHERE user_code = ? AND password = ?",[user_code,password],(error,result)=>{
          if(error){
            console.log("Query Error"+error);
          }
          else{
            if(result.length>0){
                console.log("Login Success");
                res.status(200).json(
                    {
                        status : true,
                        "msg" : "Login Successfully"
                    }
                )
            }
            else{
                console.log("Invalid Credentials");
                res.status(401).json(
                    {
                        status : false,
                        'msg': 'Invalid Credentials'
                    }
                )
            }
          }
       });
        
    } catch (error) {
        res.status(500).json({
            "status":"500",
            "msg":"Internal Server Error! CAUSED BY: "+error.message
        });
    }
});



module.exports = router;