const app = require('./Configuration/conf');
const port = 8091;


app.listen(port,()=>{
    console.log(`Server is listening at http:localhost${port}`);
});