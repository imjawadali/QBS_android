const express = require('express');
const app = express();



const auth_model = require('../Model/auth-Model/auth-model');
const inventory_transfer_req_model = require('../Model/Inventory-Transfer-Request-Model/inventory-transfer-request-Model');

app.use(express.json());


app.use('/auth',auth_model);
app.use('/ITR',inventory_transfer_req_model);



module.exports = app;