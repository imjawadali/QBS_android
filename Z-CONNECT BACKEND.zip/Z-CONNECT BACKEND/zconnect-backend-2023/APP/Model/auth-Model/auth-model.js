const express = require('express');
const router = express.Router();

const login_controller = require('../../Controllers/auth-Controllers/login-controller');
const signup_controller = require('../../Controllers/auth-Controllers/signup-controllers');



router.use('/login',login_controller);
router.use('/signup',signup_controller);




module.exports = router;