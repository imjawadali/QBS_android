const express = require('express');
const router = express.Router();



const zc_warehouse_location_retriever_controller = require('../../Controllers/ZC-Warehouse-Controllers/zc_warehouse-location-retriever');
const zc_warehouse_name_retriever_controller = require('../../Controllers/ZC-Warehouse-Controllers/zc-warehouse-name-retriever');
const zc_warehouse_whs_name_retriever_controller = require('../../Controllers/ZC-Warehouse-Controllers/zc-warehouse-whs_name-retriever');
const zc_stock_barcode_item_name_and_item_code_controller = require('../../Controllers/ZC-Warehouse-Controllers/zc-stock-barcode-item_name-item_code-retriever');
const all_zc_stock_barcode_and_stock_master_item_name_item_code = require('../../Controllers/ZC-Warehouse-Controllers/zc-stock_barcode-and-stock_master-all-item_name-item_code');


router.use('/retrieve-warehouse-location',zc_warehouse_location_retriever_controller);
router.use('/retrieve-warehouse-name',zc_warehouse_name_retriever_controller);
router.use('/retrieve-warehouse-whs-name',zc_warehouse_whs_name_retriever_controller);
router.use('/retrieve-zc-stock-barcode-item-name-item-code',zc_stock_barcode_item_name_and_item_code_controller);
router.use('/retrieve-all-zc-stock-barcode-and-stock-master-item-name-item-code',all_zc_stock_barcode_and_stock_master_item_name_item_code);

module.exports = router;