package com.example.communityapplication.ViewHolder;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class RowGateViewHolder extends RecyclerView.ViewHolder {
    public RowGateViewHolder(View itemView) {
        super(itemView);

    }
}

