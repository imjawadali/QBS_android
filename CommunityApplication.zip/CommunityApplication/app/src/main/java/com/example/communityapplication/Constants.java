package com.example.communityapplication;

public class Constants {
    public static final String USER_DATA = "user_data";

}
