const express = require('express');
const router = express.Router();
router.use(express.json());


router.post('/',(req,res)=>{
    res.status(500).json(
        {
            status : 'false',
            method : 'method not allowed'
        }
    )
});


router.get('/',(req,res)=>{
      res.status(200).json(
       [
        {
            title : 'Yarn',
            subtitle : 'Fabric',
            initialprice : '20',
            actualprice : '10$',
            image : 'https://images.unsplash.com/photo-1586880244406-556ebe35f282?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZWNvbW1lcmNlfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
        },
        {
            title : 'Apparel',
            subtitle : 'Yarn',
            initialprice : '20',
            actualprice : '10$',
            image : 'https://plus.unsplash.com/premium_photo-1683936163027-4d201065a84e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8ZWNvbW1lcmNlfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
        },
        {
            title : 'Finished',
            subtitle : 'Cotton',
            initialprice : '20',
            actualprice : '10$',
            image : 'https://images.unsplash.com/photo-1586880244386-8b3e34c8382c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGVjb21tZXJjZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
        },
        {
            title : 'Cotton',
            subtitle : 'Yarn',
            initialprice : '20',
            actualprice : '10$',
            image : 'https://plus.unsplash.com/premium_photo-1684785618727-378a3a5e91c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGVjb21tZXJjZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
        },
        {
            title : 'Apparel',
            subtitle : 'Fabric',
            initialprice : '20',
            actualprice : '10$',
            image : 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGVjb21tZXJjZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
        },
        {
            title : 'Apparel',
            subtitle : 'Fabric',
            initialprice : '20',
            actualprice : '10$',
            image : 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGVjb21tZXJjZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
        },

       ]
      )
});

module.exports = router;