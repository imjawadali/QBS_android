const express = require('express');
const mysql = require('./Database/dbconnection');
const router = express.Router();
router.use(express.json());



router.get('/',(req,res)=>{
        res.status(500).json(
            {
                status : 'false',
                method : 'method not allowed'
            }
        )
});


router.post('/',(req,res)=>{
     const {name,email,password} = req.body;
     console.log(req.body);
     try{
        mysql.query("INSERT INTO signup (name,email,password) VALUES (?,?,?)",[name,email,password],(error,result)=>{
            
            if(result){
                console.log("Query is executed");
                res.status(200).send(
                    {
                        status: true,
                        method: 'API endpoint called successfully'
                    }
                )
            }
            else if(error){
                console.log("Query is not executed");
            }
         });
     }
     catch(error){
        console.log("Exception Occured",error);
        res.status(500).json(
            {
                status : false,
                method : "An internal server error occured"
            }
        )
     }
   

});


module.exports = router;




















// else if(result.length>0){
//     mysql.query("SELECT name FROM signup WHERE email = ?",[email],(error,result)=>{
//         console.log(result.name);
//            res.status(200).json({
//                name : result.name
//            });
//     });
// }