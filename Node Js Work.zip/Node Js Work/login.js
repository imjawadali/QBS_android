const express = require('express');
const mysql = require('./Database/dbconnection');
const router = express.Router();
router.use(express.json());


router.get("/",(req,res)=>{

       res.status(405).json(
        {
            status : 'false',
            type: 'method not allowed'
        }
       )
});


router.post("/",(req,res)=>{
    const {email,password} = req.body;
    console.log(req.body);
        try{
            mysql.query("SELECT * FROM signup WHERE email = ? AND password = ?", [email,password], (error,results)=>{
                if(error){
                   console.log("Not executed query");
                }
                else {
                    if(results.length > 0){
                    console.log("User Login Sucessfully");
                    res.status(200).json(
                        {
                            status: true,
                            method: 'API endpoint called successfully'
                        }
                    )
                }
                else{
                    console.log(" Invalid email or password");
                    res.status(401).json(
                        {
                            status : false,
                            method : "Invalid email and password"
                        }
                    )
                }
            }
               });
        }
       catch(error){
          console.log("Exception occurred",error);
          res.status(500).json(
            {
                status : false,
                method : "An internal server occured"
            }
          )
       }
       

       
});

module.exports = router;