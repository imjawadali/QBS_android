const mysql = require('mysql');

const connection = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'practicework'
});

connection.connect(error=>{
           if(error){
            console.log("Failed to connect database");
           }
           else{
            console.log("Connected to database");
           }
});
module.exports = connection;