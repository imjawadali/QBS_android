const express = require('express');
const router = express.Router();
router.use(express.json());


router.post('/',(req,res)=>{
    res.status(500).json({
        status : 'false',
        type: 'method not allowed'
       });
});



router.get('/',(req,res)=>{
      res.status(200).json(
        [
            {
                title : 'Yarn',
                subtitle : 'Fabric',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y3J5cHRvfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Apparel',
                subtitle : 'Cotton',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1605792657660-596af9009e82?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8Y3J5cHRvfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Denim',
                subtitle : 'Cloth',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1634704784915-aacf363b021f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8Y3J5cHRvfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Yarn',
                subtitle : 'Cotton',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1523961131990-5ea7c61b2107?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Y3J5cHRvfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Yarn',
                subtitle : 'Fabric',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1590859808308-3d2d9c515b1a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGNyeXB0b3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Apparel',
                subtitle : 'Cotton',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1640340434855-6084b1f4901c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fGNyeXB0b3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Yarn',
                subtitle : 'Fabric',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://plus.unsplash.com/premium_photo-1677487978436-75c1acd74728?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fGNyeXB0b3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Apparel',
                subtitle : 'Cotton',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1615992174118-9b8e9be025e7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGNyeXB0b3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Yarn',
                subtitle : 'Fabric',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1626162953675-544bf5a61ca6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjZ8fGNyeXB0b3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
            },
            {
                title : 'Apparel',
                subtitle : 'Cotton',
                sellinitialprice : '20',
                sellactualprice : '10$',
                buyinitialprice : '$30',
                buyactualprice : '-2.36%',
                image : 'https://images.unsplash.com/photo-1630048421776-1f552787465d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjh8fGNyeXB0b3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
            },
        ]
      )
});




module.exports = router;