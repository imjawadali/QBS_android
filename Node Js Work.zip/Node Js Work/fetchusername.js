const express = require('express');
const mysql = require('./Database/dbconnection');
const router = express.Router();
router.use(express.json());


router.post('/', (req, res) => {
    const { email } = req.body;
    console.log(req.body);
    try {
      mysql.query(
        'SELECT name FROM signup WHERE email = ?',
        [email],
        (error, result) => {
          if (error) {
            console.log('Query is not executed');
            res.status(500).json({
              status: false,
              method: 'An internal server error occurred'
            });
          } else {
            if (result.length > 0) {
              console.log('Query is executed');
              res.status(200).json({
                status: true,
                method: result[0].name
              });
            } else {
              console.log('User not found');
              res.status(404).json({
                error: 'User not found'
              });
            }
          }
        }
      );
    } catch (error) {
      console.log('Exception Occurred', error);
      res.status(500).json({
        status: false,
        method: 'An internal server error occurred'
      });
    }
  });
  
  module.exports = router;  
  
  
  
  
  
  