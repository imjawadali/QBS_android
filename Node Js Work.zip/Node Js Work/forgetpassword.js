const express = require('express');
const mysql = require('./Database/dbconnection');
const router = express.Router();
const nodemailer = require('nodemailer');
const generatePassword = require('generate-password');
router.use(express.json());


router.get('/',(req,res)=>{
        res.status(500).json(
            { 
                  status : 'false',
                  type: 'method not allowed'
            }
        )
});




router.post('/',async(req,res)=>{
      const {email} = req.body;
      console.log(req.body);
      const temporaryPassword = generateNumericPassword(6);
      mysql.query("UPDATE signup SET password = ? WHERE email = ?",[temporaryPassword,email],(error,result)=>{
              if(error){
                  console.log(error);
                  res.status(500).json({error : "An internal server error occurred"});
              }
              else{
                  if(result.affectedRows>0){
                        console.log("Query executed");
                        sendPasswordResetEmail(email,temporaryPassword)
                      
                        res.status(200).json(
                              {
                                    status : true,
                                    method : "email sent successfully"
                              }
                        )
                  }
                  else{
                        res.status(404).json({ error: 'User not found' });
                  }
              }

      });
});

function generateNumericPassword(length) {
      const charset = '0123456789';
      let password = '';
      for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
      }
      return password;
    }

// Corrected function syntax
async function sendPasswordResetEmail(email,temporaryPassword){
      const transporter = nodemailer.createTransport({
          service:"gmail",
          host : 'smtp.gmail.com',
          port : 587,
            auth : {
                 user : 'saqib.su84@gmail.com',
                 pass : 'fofbkzyebkgobbsl',
            },
      });

      const mailOptions = {
            from : 'saqib.su84@gmail.com',
            to : email,
            subject : 'Password Reset',
            text : `your Temporary password is ${temporaryPassword}`,
      };

      transporter.sendMail(mailOptions,(error,info)=>{
          if(error){
            console.log(error);
          }
          else{
            console.log('Email Sent '+info.response);
          }
      });
}


module.exports = router;
