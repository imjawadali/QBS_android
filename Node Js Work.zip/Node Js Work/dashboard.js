const express = require('express');
const router = express.Router();
router.use(express.json());

router.get('/',(req,res)=>{
      try{
            res.status(200).json(
                [
                    {
                        title : 'Saqib',
                        subtitle : 'Finished Yarn',
                        initialprice : '20',
                        actualprice : '10$',
                        image : 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Apparel',
                        subtitle : 'Printed Fabric',
                        initialprice : '$110',
                        actualprice : '80$',
                        image : 'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Yarn',
                        subtitle : 'Dyed Yarn',
                        initialprice : '$50',
                        actualprice : '30$',
                        image : 'https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Apparel',
                        subtitle : 'Denim',
                        initialprice : '$210',
                        actualprice : '190$',
                        image : 'https://plus.unsplash.com/premium_photo-1671030274122-b6ac34f87b8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Apparel',
                        subtitle : 'Jacket Fabric',
                        initialprice : '60',
                        actualprice : '40$',
                        image : 'https://images.unsplash.com/photo-1592878904946-b3cd8ae243d0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Yarn',
                        subtitle : 'Finished Yarn',
                        initialprice : '$220',
                        actualprice : '200$',
                        image : 'https://plus.unsplash.com/premium_photo-1675186049563-000f7ac02c44?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Yarn',
                        subtitle : 'Finished Yarn',
                        initialprice : '$220',
                        actualprice : '200$',
                        image : 'https://images.unsplash.com/photo-1555583743-991174c11425?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjJ8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Yarn',
                        subtitle : 'Finished Yarn',
                        initialprice : '$220',
                        actualprice : '200$',
                        image : 'https://images.unsplash.com/photo-1620780327051-f7ad06f5b1e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjd8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Yarn',
                        subtitle : 'Finished Yarn',
                        initialprice : '$220',
                        actualprice : '200$',
                        image : 'https://plus.unsplash.com/premium_photo-1675186049563-000f7ac02c44?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Tum',
                        subtitle : 'Finished Yarn',
                        initialprice : '$220',
                        actualprice : '200$',
                        image : 'https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8amFja2V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'
                    },
                    {
                        title : 'Apparel',
                        subtitle : 'Denim',
                        initialprice : '$210',
                        actualprice : '190$',
                        image : 'https://plus.unsplash.com/premium_photo-1671030274122-b6ac34f87b8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fGphY2tldHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60'
                    },
                ]
            )
      }
      catch(error){
        console.log(error);
        res.status(500).json(
            {
                status : false,
                method : "An internal server occured"
            }
        )
      }
});


router.post('/',(req,res)=>{
       res.status(500).json({
        status : 'false',
        type: 'method not allowed'
       });
});

module.exports = router;