const express = require('express');
const app = express();
const port = 8080;

const login_api = require('./login');
const signup_api = require('./signup');
const forgetpassword_api = require('./forgetpassword');
const dashboard_api = require('./dashboard');
const dashboardmarket_api = require('./dashboardmarket');
const market_api = require('./market');
const fetchusername_api = require('./fetchusername');



app.use("/login",login_api);
app.use("/signup",signup_api);
app.use("/forgetpassword",forgetpassword_api);
app.use('/dashboard',dashboard_api);
app.use('/dashboardmarket',dashboardmarket_api);
app.use('/market',market_api);
app.use("/fetchusername",fetchusername_api);


app.listen(port,()=>{
    console.log(`Server is running at ${port}`);
});

