package com.example.shakerapplication.ModelClasses;

public class Load_Plants_Model_Class {
    String Werks;

    public Load_Plants_Model_Class(String werks) {
        Werks = werks;
    }

    public String getWerks() {
        return Werks;
    }

    public void setWerks(String werks) {
        Werks = werks;
    }
}

