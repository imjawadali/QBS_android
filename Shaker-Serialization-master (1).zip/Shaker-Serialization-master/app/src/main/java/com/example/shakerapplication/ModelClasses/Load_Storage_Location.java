package com.example.shakerapplication.ModelClasses;

public class Load_Storage_Location {
    String LGORT;

    public Load_Storage_Location(String LGORT) {
        this.LGORT = LGORT;
    }


    public String getLGORT() {
        return LGORT;
    }

    public void setLGORT(String LGORT) {
        this.LGORT = LGORT;
    }
}
