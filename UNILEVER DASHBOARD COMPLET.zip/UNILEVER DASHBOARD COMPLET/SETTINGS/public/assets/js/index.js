const accordionItemHeaders = document.querySelectorAll(".accordion-item-header");

accordionItemHeaders.forEach(accordionItemHeader => {
   accordionItemHeader.addEventListener("click", event => {
    
     // Uncomment in case you only want to allow for the display of only one collapsed item at a time!
    
//     const currentlyActiveAccordionItemHeader = document.querySelector(".accordion-item-header.active");
//     if(currentlyActiveAccordionItemHeader && currentlyActiveAccordionItemHeader!==accordionItemHeader) {
//        currentlyActiveAccordionItemHeader.classList.toggle("active");
//        currentlyActiveAccordionItemHeader.nextElementSibling.style.maxHeight = 0;
//      }

     accordionItemHeader.classList.toggle("active");
     const accordionItemBody = accordionItemHeader.nextElementSibling;
     if(accordionItemHeader.classList.contains("active")) {
      accordionItemBody.style.maxHeight = accordionItemBody.scrollHeight + "px";
     }
     else {
       accordionItemBody.style.maxHeight = 0;
     }
    
   });
});

// const togglePassword = document.querySelector("#togglePassword");
//         const password = document.querySelector("#password");

//         togglePassword.addEventListener("click", function () {
//             // toggle the type attribute
//             const type = password.getAttribute("type") === "password" ? "text" : "password";
//             password.setAttribute("type", type);
            
//             // toggle the icon
//             this.classList.toggle("bi-eye");
//         });

//         // prevent form submit
//         const form = document.querySelector("form");
//         form.addEventListener('submit', function (e) {
//             e.preventDefault();
//         });
 
// $(document).ready(function() {
//   $("#show_hide_password a").on('click', function(event) {
//       event.preventDefault();
//       if($('#show_hide_password input').attr("type") == "text"){
//           $('#show_hide_password input').attr('type', 'password');
//           $('#show_hide_password i').addClass( "fa-eye-slash" );
//           $('#show_hide_password i').removeClass( "fa-eye" );
//       }else if($('#show_hide_password input').attr("type") == "password"){
//           $('#show_hide_password input').attr('type', 'text');
//           $('#show_hide_password i').removeClass( "fa-eye-slash" );
//           $('#show_hide_password i').addClass( "fa-eye" );
//       }
//   });
// });
const togglePassword = document.querySelector("#togglePassword");
const password = document.querySelector("#password");

togglePassword.addEventListener("click", function () {
   
  // toggle the type attribute
  const type = password.getAttribute("type") === "password" ? "text" : "password";
  password.setAttribute("type", type);
  // toggle the eye icon
  this.classList.toggle('fa-eye');
  this.classList.toggle('fa-eye-slash');
});


const togglerRePassword = document.querySelector("#togglerRePassword");
const repassword = document.querySelector("#repassword");

togglerRePassword.addEventListener("click", function () {
   
  // toggle the type attribute
  const type = repassword.getAttribute("type") === "password" ? "text" : "password";
  repassword.setAttribute("type", type);
  // toggle the eye icon
  this.classList.toggle('fa-eye');
  this.classList.toggle('fa-eye-slash');
});